import pickle
import numpy as np

class Model2:
    def __init__(self, model_path='model.pkl'):
        # Load the model from the specified file
        with open(model_path, 'rb') as f:
            self.model = pickle.load(f)
    
    def preprocess(X):
        processed_X = ...
        return processed_X

    def predict(self, X):
        # Please fill this method in to take in a test set X and output the predictions on X
        processed_X = self.preprocess(X)
        y_pred = np.zeros(100) # TODO: change this

        return y_pred